"""
Taller 3D — Sistema de gestión y control financiero para impresión 3D.
Ejecutar:  python app.py   ->  http://127.0.0.1:5000
"""
import os
import io
import csv
import re
import uuid
import zipfile
from datetime import date, datetime

from flask import (Flask, render_template, request, redirect, url_for, flash,
                   Response, jsonify, send_from_directory)
from werkzeug.utils import secure_filename

EXTENSIONES_GCODE = (".gcode", ".gco", ".3mf")
from flask_login import (LoginManager, login_user, logout_user,
                         login_required, current_user)
from flask_bcrypt import Bcrypt
from sqlalchemy import extract, inspect, text

from config import Config
from models import (db, User, Filamento, Proyecto, Venta, Gasto,
                    Liquidacion, Inversion, AbonoInversion)

MESES = ["", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
         "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]

# Credenciales sembradas por defecto en el primer arranque.
# IMPORTANTE: cambia estas contraseñas después de iniciar sesión.
SOCIOS_SEED = [
    {"username": "jorge", "nombre": "Jorge", "color": "#2dd4bf", "password": "jorge123"},
    {"username": "tefi",  "nombre": "Tefi",  "color": "#22d3ee", "password": "tefi123"},
]

# Sugerencias del "Agente" (Brújula de Tendencias). Locales, sin APIs externas.
TENDENCIAS_VIRALES = [
    {"icono": "🗂️", "titulo": "Organizadores de escritorio modulares para setups tech",
     "tip": "Idea de Reel: arma el organizador pieza por pieza en un timelapse y cierra con el setup ordenado."},
    {"icono": "🦴", "titulo": "Modelos anatómicos y maquetas mecánicas para estudiantes",
     "tip": "Idea de Reel: muestra el modelo girando 360° y explica una curiosidad en 15 segundos."},
    {"icono": "📷", "titulo": "Soportes de cámara y gadgets útiles (Pocket 3, GoPro, celular)",
     "tip": "Idea de Reel: graba un timelapse de la impresión con tu Pocket 3 y muestra el accesorio en uso."},
    {"icono": "🎮", "titulo": "Soportes de control y auriculares para gamers",
     "tip": "Idea de Reel: 'Antes y después' del escritorio gamer con el soporte instalado."},
    {"icono": "🪴", "titulo": "Materas geométricas y decoración minimalista",
     "tip": "Idea de Reel: satisfying del relleno de tierra + plantita, con música trend."},
]

bcrypt = Bcrypt()
login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.login_message = "Inicia sesión para continuar."


@login_manager.user_loader
def cargar_usuario(user_id):
    return db.session.get(User, int(user_id))


def crear_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    # Límite de subida para archivos de slicer (.gcode pueden ser grandes)
    app.config.setdefault("MAX_CONTENT_LENGTH", 128 * 1024 * 1024)  # 128 MB

    # Asegura que existan las carpetas de datos locales
    os.makedirs(os.path.join(app.root_path, "instance"), exist_ok=True)
    os.makedirs(os.path.join(app.root_path, "instance", "gcodes"), exist_ok=True)

    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)

    with app.app_context():
        db.create_all()
        migrar_esquema()
        migrar_y_sembrar_usuarios()

    registrar_rutas(app)
    return app


def migrar_esquema():
    """Añade columnas nuevas a BDs existentes sin borrar datos (SQLite ALTER)."""
    with db.engine.begin() as conn:
        fil_cols = [c["name"] for c in inspect(db.engine).get_columns("filamentos")]
        if "stock_minimo" not in fil_cols:
            conn.execute(text(
                "ALTER TABLE filamentos ADD COLUMN stock_minimo FLOAT DEFAULT 200"))

        proy_cols = [c["name"] for c in inspect(db.engine).get_columns("proyectos")]
        if "fecha_entrega" not in proy_cols:
            conn.execute(text("ALTER TABLE proyectos ADD COLUMN fecha_entrega DATE"))
        if "gcode_filename" not in proy_cols:
            conn.execute(text("ALTER TABLE proyectos ADD COLUMN gcode_filename VARCHAR(120)"))
        if "precio_total" not in proy_cols:
            conn.execute(text("ALTER TABLE proyectos ADD COLUMN precio_total FLOAT DEFAULT 0"))
        if "adelanto" not in proy_cols:
            conn.execute(text("ALTER TABLE proyectos ADD COLUMN adelanto FLOAT DEFAULT 0"))


def migrar_y_sembrar_usuarios():
    """
    Evoluciona la tabla 'usuarios' para autenticación y siembra jorge/tefi.
    - Añade las columnas username/password_hash si no existen (sin borrar datos).
    - Convierte socios legacy (sin username) en jorge/tefi conservando su id
      (y por tanto las claves foráneas de ventas/gastos/proyectos).
    """
    cols = [c["name"] for c in inspect(db.engine).get_columns("usuarios")]
    with db.engine.begin() as conn:
        if "username" not in cols:
            conn.execute(text("ALTER TABLE usuarios ADD COLUMN username VARCHAR(80)"))
        if "password_hash" not in cols:
            conn.execute(text("ALTER TABLE usuarios ADD COLUMN password_hash VARCHAR(200)"))

    def _hash(pw):
        return bcrypt.generate_password_hash(pw).decode("utf-8")

    usuarios = User.query.order_by(User.id).all()
    if not usuarios:
        # BD nueva: crea jorge y tefi
        for s in SOCIOS_SEED:
            db.session.add(User(username=s["username"], nombre=s["nombre"],
                                color=s["color"], password_hash=_hash(s["password"])))
    else:
        # Normaliza filas legacy (sin username) a jorge/tefi por orden de id
        legacy = [u for u in usuarios if not u.username]
        for u, s in zip(legacy, SOCIOS_SEED):
            u.username, u.nombre, u.color = s["username"], s["nombre"], s["color"]
            u.password_hash = _hash(s["password"])
        # Crea los que falten (por si había menos de 2 socios)
        existentes = {u.username for u in User.query.all() if u.username}
        for s in SOCIOS_SEED:
            if s["username"] not in existentes:
                db.session.add(User(username=s["username"], nombre=s["nombre"],
                                    color=s["color"], password_hash=_hash(s["password"])))
    db.session.commit()


# --------------------------------------------------------------------------
#  Helpers de periodo (filtros por mes/año)
# --------------------------------------------------------------------------
def parse_periodo(valor):
    """Convierte 'YYYY-MM' (input type=month) a (año, mes). Default: mes actual."""
    if valor:
        try:
            y, m = valor.split("-")
            y, m = int(y), int(m)
            if 1 <= m <= 12:
                return y, m
        except (ValueError, AttributeError):
            pass
    hoy = date.today()
    return hoy.year, hoy.month


def periodo_str(anio, mes):
    return f"{anio:04d}-{mes:02d}"


def etiqueta_periodo(anio, mes):
    return f"{MESES[mes]} {anio}"


def mes_relativo(anio, mes, delta):
    """Devuelve (año, mes) desplazado 'delta' meses (puede ser negativo)."""
    total = (anio * 12 + (mes - 1)) + delta
    return total // 12, (total % 12) + 1


# --------------------------------------------------------------------------
#  Lógica financiera (el corazón del "conteo de la plata")
# --------------------------------------------------------------------------
def calcular_balance(anio=None, mes=None):
    """
    Devuelve el resumen financiero global y el balance por socio.

    Regla contable (unificación Proyectos/Ventas):
      - El ingreso de un pedido SOLO se reconoce cuando está 'Entregado' o su
        saldo pendiente es 0 (pagado en su totalidad). Los adelantos/pagos
        parciales no se suman hasta entonces (ver Proyecto.ingreso_reconocido).

    Regla de reparto:
      - Ganancia neta total = Ingresos reconocidos - Gastos
      - Cada socio tiene derecho al 50% de la ganancia neta.
      - 'Aporte' de un socio = gastos que pagó de su bolsillo.
      - 'Cobrado' de un socio = ingresos reconocidos de los pedidos que registró.
      - 'En mano' = cobrado - aporte  (efectivo real que tiene ahora)
      - 'Ajuste'  = lo que debería tener (50% ganancia) - lo que tiene en mano.
                    Positivo = le deben plata / Negativo = debe plata.
    """
    usuarios = User.query.all()

    # Filtra proyectos/gastos por mes (proyectos por su fecha de creación) si aplica
    pq, gq = Proyecto.query, Gasto.query
    if anio and mes:
        pq = pq.filter(extract("year", Proyecto.creado) == anio,
                       extract("month", Proyecto.creado) == mes)
        gq = gq.filter(extract("year", Gasto.fecha) == anio,
                       extract("month", Gasto.fecha) == mes)
    proyectos, gastos = pq.all(), gq.all()

    # Liquidaciones (transferencias entre socios) del mismo periodo. NO son
    # ingresos ni gastos: solo reacomodan el efectivo en mano de cada socio.
    lq = Liquidacion.query
    if anio and mes:
        lq = lq.filter(Liquidacion.anio == anio, Liquidacion.mes == mes)
    liquidaciones = lq.all()

    # Solo cuentan los pedidos entregados o cancelados en su totalidad
    total_ingresos = sum(p.ingreso_reconocido for p in proyectos)
    total_gastos = sum(g.monto for g in gastos)
    ganancia_neta = total_ingresos - total_gastos

    n = len(usuarios) or 1
    parte_justa = ganancia_neta / n  # 50% si son 2 socios

    balance_socios = []
    for u in usuarios:
        cobrado = sum(p.ingreso_reconocido for p in proyectos if p.usuario_id == u.id)
        aporte = sum(g.monto for g in gastos if g.usuario_id == u.id)
        # Efecto de las liquidaciones ya registradas: recibió suma, pagó resta
        recibido = sum(l.monto for l in liquidaciones if l.receptor_id == u.id)
        pagado = sum(l.monto for l in liquidaciones if l.pagador_id == u.id)
        en_mano = cobrado - aporte + recibido - pagado
        ajuste = parte_justa - en_mano
        balance_socios.append({
            "usuario": u,
            "cobrado": cobrado,
            "aporte": aporte,
            "liquidado": recibido - pagado,
            "en_mano": en_mano,
            "parte_justa": parte_justa,
            "ajuste": ajuste,
        })

    # Sugerencia para 'quedar a mano': quien tiene de más le paga a quien tiene
    # de menos, por el monto exacto del ajuste. None si ya están parejos.
    liquidacion_sugerida = None
    if balance_socios:
        receptor = max(balance_socios, key=lambda s: s["ajuste"])   # ajuste > 0 → le deben
        pagador = min(balance_socios, key=lambda s: s["ajuste"])    # ajuste < 0 → debe
        monto = round(min(receptor["ajuste"], -pagador["ajuste"]), 2)
        if receptor["usuario"].id != pagador["usuario"].id and monto > 0.5:
            liquidacion_sugerida = {
                "pagador": pagador["usuario"],
                "receptor": receptor["usuario"],
                "monto": monto,
            }

    return {
        "total_ingresos": total_ingresos,
        "total_gastos": total_gastos,
        "ganancia_neta": ganancia_neta,
        "parte_justa": parte_justa,
        "socios": balance_socios,
        "liquidacion_sugerida": liquidacion_sugerida,
    }


def _texto_de_archivo_slicer(data, filename=""):
    """Extrae texto de un .gcode (texto plano) o .3mf (ZIP con configs/XML)."""
    if zipfile.is_zipfile(io.BytesIO(data)):
        partes = []
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for name in z.namelist():
                if name.lower().endswith((".config", ".xml", ".gcode", ".txt", ".json")):
                    try:
                        partes.append(z.read(name).decode("utf-8", "ignore"))
                    except Exception:
                        pass
        return "\n".join(partes)
    return data.decode("utf-8", "ignore")


def _fragmento_a_horas(frag):
    """Convierte '1d 2h 30m 15s' -> horas (float)."""
    d = re.search(r"(\d+)\s*d", frag)
    h = re.search(r"(\d+)\s*h", frag)
    mi = re.search(r"(\d+)\s*m", frag)
    s = re.search(r"(\d+)\s*s", frag)
    total = 0.0
    if d:  total += int(d.group(1)) * 24
    if h:  total += int(h.group(1))
    if mi: total += int(mi.group(1)) / 60
    if s:  total += int(s.group(1)) / 3600
    return round(total, 2) if total else None


def parsear_metadatos_slicer(data, filename=""):
    """
    Lee los metadatos de peso (g) y tiempo de impresión desde un archivo de
    slicer (PrusaSlicer/Orca/Bambu/SuperSlicer/Cura, .gcode o .3mf) con regex.
    Devuelve dict {peso_g, tiempo_h}. Valores None si no se encuentran.
    """
    texto = _texto_de_archivo_slicer(data, filename)

    # ---- Peso en gramos ----
    peso = None
    patrones_peso = [
        r"total\s+filament\s+(?:used|weight)\s*\[?g\]?\s*[:=]\s*([\d.]+)",  # total explícito
        r'used_g="([\d.]+)"',                         # .3mf slice_info (por filamento)
        r'key="weight"\s+value="([\d.]+)"',           # .3mf metadata
        r"filament\s+used\s*\[g\]\s*[:=]\s*([\d.]+)",  # PrusaSlicer/Orca por herramienta
        r"filament\s+weight[^\d]*([\d.]+)\s*g",       # genérico "filament weight: X g"
    ]
    for pat in patrones_peso:
        encontrados = re.findall(pat, texto, re.I)
        if encontrados:
            # Suma (varios filamentos) salvo que el patrón ya sea un total
            peso = round(sum(float(x) for x in encontrados), 2)
            break

    # ---- Tiempo en horas ----
    tiempo = None
    m = re.search(r";TIME:(\d+)", texto)                         # Cura (segundos)
    if not m:
        m = re.search(r'key="prediction"\s+value="(\d+)"', texto, re.I)  # .3mf (segundos)
    if m:
        tiempo = round(int(m.group(1)) / 3600, 2)
    else:
        etq = re.search(
            r"(?:estimated printing time[^\n=:]*|total estimated time|model printing time)"
            r"\s*[:=]\s*([0-9hdms \t]+)", texto, re.I)
        if etq:
            tiempo = _fragmento_a_horas(etq.group(1))

    return {"peso_g": peso, "tiempo_h": tiempo}


def obtener_proyectos_urgentes():
    """
    Proyectos NO entregados que vencen en <= 2 días o ya están retrasados,
    ordenados por urgencia (más retrasado / próximo primero).
    """
    candidatos = Proyecto.query.filter(Proyecto.estado != "Entregado").all()
    urgentes = [p for p in candidatos if p.es_urgente]
    urgentes.sort(key=lambda p: p.dias_restantes)
    return urgentes


# --------------------------------------------------------------------------
#  Rutas
# --------------------------------------------------------------------------
def registrar_rutas(app):

    # ---------- Contexto global (disponible en TODAS las plantillas) ----------
    @app.context_processor
    def inyectar_alertas_stock():
        """Cuenta filamentos bajo stock mínimo para el badge de la nav."""
        if not current_user.is_authenticated:
            return {"conteo_alertas": 0}
        conteo = sum(1 for f in Filamento.query.all() if f.bajo_stock)
        return {"conteo_alertas": conteo}

    # ---------- Autenticación ----------
    @app.route("/login", methods=["GET", "POST"])
    def login():
        if current_user.is_authenticated:
            return redirect(url_for("dashboard"))
        if request.method == "POST":
            username = request.form.get("username", "").strip().lower()
            password = request.form.get("password", "")
            user = User.query.filter_by(username=username).first()
            if user and user.password_hash and \
                    bcrypt.check_password_hash(user.password_hash, password):
                login_user(user)
                destino = request.args.get("next") or url_for("dashboard")
                return redirect(destino)
            flash("Usuario o contraseña incorrectos.", "error")
        return render_template("login.html")

    @app.route("/logout")
    @login_required
    def logout():
        logout_user()
        flash("Sesión cerrada correctamente.", "ok")
        return redirect(url_for("login"))

    def _parse_fecha(valor):
        if not valor:
            return date.today()
        return datetime.strptime(valor, "%Y-%m-%d").date()

    def _parse_fecha_opt(valor):
        """Fecha opcional: None si el campo viene vacío."""
        if not valor:
            return None
        return datetime.strptime(valor, "%Y-%m-%d").date()

    def _gcodes_dir():
        return os.path.join(app.root_path, "instance", "gcodes")

    def _guardar_gcode(archivo):
        """Guarda el archivo con nombre UUID (evita colisiones). Devuelve el nombre en disco o None."""
        if not archivo or not archivo.filename:
            return None
        base = secure_filename(archivo.filename)
        ext = os.path.splitext(base)[1].lower()
        if ext not in EXTENSIONES_GCODE:
            return None
        nombre_disco = f"{uuid.uuid4().hex}{ext}"
        archivo.save(os.path.join(_gcodes_dir(), nombre_disco))
        return nombre_disco

    def _guardar_bytes_gcode(data, ext):
        """Escribe bytes en disco con nombre UUID. Devuelve el nombre en disco."""
        nombre_disco = f"{uuid.uuid4().hex}{ext}"
        with open(os.path.join(_gcodes_dir(), nombre_disco), "wb") as fh:
            fh.write(data)
        return nombre_disco

    def _borrar_gcode(nombre):
        """Borra el archivo físico si existe (evita basura en disco)."""
        if not nombre:
            return
        ruta = os.path.join(_gcodes_dir(), nombre)
        try:
            if os.path.isfile(ruta):
                os.remove(ruta)
        except OSError:
            pass

    def _filtrar_mes(query, columna_fecha, per):
        return query.filter(extract("year", columna_fecha) == per["anio"],
                            extract("month", columna_fecha) == per["mes"])

    def _csv_response(nombre, cabecera, filas):
        buf = io.StringIO()
        buf.write("﻿")  # BOM: Excel abre los acentos correctamente
        w = csv.writer(buf)
        w.writerow(cabecera)
        w.writerows(filas)
        return Response(
            buf.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename={nombre}"},
        )

    def _contexto_periodo():
        """Datos comunes del selector de mes para las plantillas."""
        anio, mes = parse_periodo(request.args.get("periodo"))
        pa, ma = mes_relativo(anio, mes, -1)
        ps, ms = mes_relativo(anio, mes, +1)
        return {
            "anio": anio, "mes": mes,
            "periodo": periodo_str(anio, mes),
            "periodo_label": etiqueta_periodo(anio, mes),
            "periodo_prev": periodo_str(pa, ma),
            "periodo_next": periodo_str(ps, ms),
        }

    # ---------- Dashboard ----------
    @app.route("/")
    @login_required
    def dashboard():
        per = _contexto_periodo()
        bal = calcular_balance(per["anio"], per["mes"])
        proyectos = Proyecto.query.order_by(Proyecto.creado.desc()).limit(6).all()
        conteo_estados = {
            e: Proyecto.query.filter_by(estado=e).count()
            for e in Proyecto.ESTADOS
        }
        # Alertas de stock crítico de filamento
        alertas_stock = [f for f in Filamento.query.all() if f.bajo_stock]
        # Agente Asistente: pedidos urgentes + tendencias
        urgentes = obtener_proyectos_urgentes()
        return render_template("dashboard.html", bal=bal, per=per,
                               proyectos=proyectos, conteo_estados=conteo_estados,
                               alertas_stock=alertas_stock,
                               urgentes=urgentes, tendencias=TENDENCIAS_VIRALES)

    # ---------- Proyectos / Impresiones ----------
    @app.route("/proyectos/parse-gcode", methods=["POST"])
    @login_required
    def parse_gcode():
        """Recibe un .gcode/.3mf por AJAX y devuelve peso (g) y tiempo (h)."""
        archivo = request.files.get("archivo")
        if not archivo or not archivo.filename:
            return jsonify({"ok": False, "error": "No se recibió ningún archivo."}), 400
        if not archivo.filename.lower().endswith((".gcode", ".gco", ".3mf")):
            return jsonify({"ok": False, "error": "Formato no soportado (usa .gcode o .3mf)."}), 400
        try:
            data = archivo.read()
            meta = parsear_metadatos_slicer(data, archivo.filename)
        except Exception as e:
            return jsonify({"ok": False, "error": f"No se pudo leer el archivo: {e}"}), 500
        if meta["peso_g"] is None and meta["tiempo_h"] is None:
            return jsonify({"ok": False,
                            "error": "No se encontraron metadatos de peso/tiempo en el archivo."}), 200
        return jsonify({"ok": True, "peso_g": meta["peso_g"],
                        "tiempo_h": meta["tiempo_h"], "archivo": archivo.filename})

    @app.route("/proyectos")
    @login_required
    def proyectos():
        lista = Proyecto.query.order_by(Proyecto.creado.desc()).all()
        return render_template("proyectos.html", proyectos=lista,
                               filamentos=Filamento.query.all(),
                               usuarios=User.query.all(),
                               estados=Proyecto.ESTADOS)

    @app.route("/proyectos/nuevo", methods=["POST"])
    @login_required
    def nuevo_proyecto():
        f = request.form
        p = Proyecto(
            nombre=f.get("nombre", "").strip(),
            cliente=f.get("cliente", "").strip(),
            estado=f.get("estado") or "Diseñando",
            peso_g=float(f.get("peso_g") or 0),
            tiempo_estimado_h=float(f.get("tiempo_estimado_h") or 0),
            filamento_id=int(f["filamento_id"]) if f.get("filamento_id") else None,
            fecha_entrega=_parse_fecha_opt(f.get("fecha_entrega")),
            precio_total=float(f.get("precio_total") or 0),
            adelanto=float(f.get("adelanto") or 0),
            usuario_id=current_user.id,  # registra automáticamente al usuario autenticado
        )
        if not p.nombre:
            flash("El nombre del proyecto es obligatorio.", "error")
        else:
            # Guarda físicamente el G-code/3MF subido con el formulario
            p.gcode_filename = _guardar_gcode(request.files.get("gcode_file"))
            db.session.add(p)
            db.session.commit()
            flash("Proyecto creado.", "ok")
        return redirect(url_for("proyectos"))

    @app.route("/proyectos/<int:pid>/estado", methods=["POST"])
    @login_required
    def cambiar_estado(pid):
        p = Proyecto.query.get_or_404(pid)
        nuevo = request.form.get("estado")
        if nuevo in Proyecto.ESTADOS:
            p.estado = nuevo
            db.session.commit()
        return redirect(url_for("proyectos"))

    @app.route("/proyectos/<int:pid>/editar", methods=["GET", "POST"])
    @login_required
    def editar_proyecto(pid):
        p = Proyecto.query.get_or_404(pid)
        if request.method == "POST":
            f = request.form
            p.nombre = f.get("nombre", "").strip() or p.nombre
            p.cliente = f.get("cliente", "").strip()
            p.estado = f.get("estado") if f.get("estado") in Proyecto.ESTADOS else p.estado
            p.peso_g = float(f.get("peso_g") or 0)
            p.tiempo_estimado_h = float(f.get("tiempo_estimado_h") or 0)
            p.filamento_id = int(f["filamento_id"]) if f.get("filamento_id") else None
            p.fecha_entrega = _parse_fecha_opt(f.get("fecha_entrega"))
            p.precio_total = float(f.get("precio_total") or 0)
            p.adelanto = float(f.get("adelanto") or 0)
            p.usuario_id = int(f["usuario_id"]) if f.get("usuario_id") else None

            # ¿Subió un archivo nuevo? -> reparsear, borrar el viejo y guardar el nuevo
            nuevo = request.files.get("gcode_file")
            if nuevo and nuevo.filename:
                ext = os.path.splitext(secure_filename(nuevo.filename))[1].lower()
                if ext in EXTENSIONES_GCODE:
                    data = nuevo.read()
                    meta = parsear_metadatos_slicer(data, nuevo.filename)
                    if meta["peso_g"] is not None:
                        p.peso_g = meta["peso_g"]
                    if meta["tiempo_h"] is not None:
                        p.tiempo_estimado_h = meta["tiempo_h"]
                    _borrar_gcode(p.gcode_filename)            # elimina el archivo viejo
                    p.gcode_filename = _guardar_bytes_gcode(data, ext)  # guarda el nuevo (UUID)
                    flash("Archivo G-code reemplazado y metadatos actualizados.", "ok")
                else:
                    flash("Formato de archivo no soportado; se conservó el anterior.", "error")
            # Si NO subió archivo, gcode_filename queda intacto.

            db.session.commit()  # el costo se recalcula solo (propiedad derivada)
            flash("Proyecto actualizado.", "ok")
            return redirect(url_for("proyectos"))
        return render_template("editar_proyecto.html", p=p,
                               filamentos=Filamento.query.all(),
                               usuarios=User.query.all(),
                               estados=Proyecto.ESTADOS)

    @app.route("/proyectos/<int:pid>/gcode")
    @login_required
    def descargar_gcode(pid):
        p = Proyecto.query.get_or_404(pid)
        if not p.gcode_filename:
            return redirect(url_for("proyectos"))
        return send_from_directory(_gcodes_dir(), p.gcode_filename, as_attachment=True)

    @app.route("/proyectos/<int:pid>/eliminar", methods=["POST"])
    @login_required
    def eliminar_proyecto(pid):
        p = Proyecto.query.get_or_404(pid)
        _borrar_gcode(p.gcode_filename)   # borra el archivo físico para no dejar basura
        db.session.delete(p)
        db.session.commit()
        return redirect(url_for("proyectos"))

    # ---------- Filamentos ----------
    @app.route("/filamentos")
    @login_required
    def filamentos():
        return render_template("filamentos.html", filamentos=Filamento.query.all())

    @app.route("/filamentos/nuevo", methods=["POST"])
    @login_required
    def nuevo_filamento():
        f = request.form
        fil = Filamento(
            tipo=f.get("tipo", "PLA").strip(),
            color=f.get("color", "").strip(),
            precio_rollo=float(f.get("precio_rollo") or 0),
            peso_rollo_g=float(f.get("peso_rollo_g") or 1000),
            stock_minimo=float(f.get("stock_minimo") or 200),
        )
        db.session.add(fil)
        db.session.commit()
        flash("Filamento agregado.", "ok")
        return redirect(url_for("filamentos"))

    @app.route("/filamentos/<int:fid>/stock", methods=["POST"])
    @login_required
    def actualizar_stock_minimo(fid):
        fil = Filamento.query.get_or_404(fid)
        fil.stock_minimo = float(request.form.get("stock_minimo") or 0)
        db.session.commit()
        flash(f"Stock mínimo de {fil.etiqueta} actualizado.", "ok")
        return redirect(url_for("filamentos"))

    @app.route("/filamentos/<int:fid>/eliminar", methods=["POST"])
    @login_required
    def eliminar_filamento(fid):
        db.session.delete(Filamento.query.get_or_404(fid))
        db.session.commit()
        return redirect(url_for("filamentos"))

    # ---------- Ventas ----------
    @app.route("/ventas")
    @login_required
    def ventas():
        per = _contexto_periodo()
        q = _filtrar_mes(Venta.query, Venta.fecha, per)
        lista = q.order_by(Venta.fecha.desc(), Venta.id.desc()).all()
        return render_template("ventas.html", ventas=lista, per=per,
                               usuarios=User.query.all(),
                               proyectos=Proyecto.query.all(),
                               metodos=Venta.METODOS,
                               total=sum(v.monto for v in lista))

    @app.route("/ventas/nueva", methods=["POST"])
    @login_required
    def nueva_venta():
        f = request.form
        v = Venta(
            descripcion=f.get("descripcion", "").strip(),
            monto=float(f.get("monto") or 0),
            metodo_pago=f.get("metodo_pago") or "Efectivo",
            fecha=_parse_fecha(f.get("fecha")),
            usuario_id=current_user.id,  # registra automáticamente al usuario autenticado
            proyecto_id=int(f["proyecto_id"]) if f.get("proyecto_id") else None,
        )
        if v.monto <= 0:
            flash("El monto debe ser mayor a 0.", "error")
        else:
            db.session.add(v)
            db.session.commit()
            flash("Venta registrada.", "ok")
        return redirect(url_for("ventas"))

    @app.route("/ventas/<int:vid>/editar", methods=["GET", "POST"])
    @login_required
    def editar_venta(vid):
        v = Venta.query.get_or_404(vid)
        if request.method == "POST":
            f = request.form
            monto = float(f.get("monto") or 0)
            if monto <= 0:
                flash("El monto debe ser mayor a 0.", "error")
                return redirect(url_for("editar_venta", vid=vid))
            v.descripcion = f.get("descripcion", "").strip()
            v.monto = monto
            v.metodo_pago = f.get("metodo_pago") or v.metodo_pago
            v.fecha = _parse_fecha(f.get("fecha"))
            v.usuario_id = int(f["usuario_id"]) if f.get("usuario_id") else None
            v.proyecto_id = int(f["proyecto_id"]) if f.get("proyecto_id") else None
            db.session.commit()
            flash("Venta actualizada.", "ok")
            return redirect(url_for("ventas"))
        return render_template("editar_venta.html", v=v,
                               usuarios=User.query.all(),
                               proyectos=Proyecto.query.all(),
                               metodos=Venta.METODOS)

    @app.route("/ventas/<int:vid>/eliminar", methods=["POST"])
    @login_required
    def eliminar_venta(vid):
        db.session.delete(Venta.query.get_or_404(vid))
        db.session.commit()
        return redirect(url_for("ventas"))

    @app.route("/ventas/export.csv")
    @login_required
    def exportar_ventas():
        per = _contexto_periodo()
        filas = _filtrar_mes(Venta.query, Venta.fecha, per) \
            .order_by(Venta.fecha.asc(), Venta.id.asc()).all()
        rows = [[
            v.fecha, v.descripcion or "", v.metodo_pago,
            v.usuario.nombre if v.usuario else "",
            v.proyecto.nombre if v.proyecto else "", f"Bs. {v.monto:,.2f}"
        ] for v in filas]
        return _csv_response(f"ventas_{per['periodo']}.csv",
                             ["Fecha", "Descripción", "Método", "Cobró", "Proyecto", "Monto (Bs.)"],
                             rows)

    # ---------- Gastos ----------
    @app.route("/gastos")
    @login_required
    def gastos():
        per = _contexto_periodo()
        q = _filtrar_mes(Gasto.query, Gasto.fecha, per)
        lista = q.order_by(Gasto.fecha.desc(), Gasto.id.desc()).all()
        return render_template("gastos.html", gastos=lista, per=per,
                               usuarios=User.query.all(),
                               categorias=Gasto.CATEGORIAS,
                               total=sum(g.monto for g in lista))

    @app.route("/gastos/nuevo", methods=["POST"])
    @login_required
    def nuevo_gasto():
        f = request.form
        g = Gasto(
            categoria=f.get("categoria") or "Otro",
            descripcion=f.get("descripcion", "").strip(),
            monto=float(f.get("monto") or 0),
            fecha=_parse_fecha(f.get("fecha")),
            usuario_id=current_user.id,  # registra automáticamente al usuario autenticado
        )
        if g.monto <= 0:
            flash("El monto debe ser mayor a 0.", "error")
        else:
            db.session.add(g)
            db.session.commit()
            flash("Gasto registrado.", "ok")
        return redirect(url_for("gastos"))

    @app.route("/gastos/<int:gid>/editar", methods=["GET", "POST"])
    @login_required
    def editar_gasto(gid):
        g = Gasto.query.get_or_404(gid)
        if request.method == "POST":
            f = request.form
            monto = float(f.get("monto") or 0)
            if monto <= 0:
                flash("El monto debe ser mayor a 0.", "error")
                return redirect(url_for("editar_gasto", gid=gid))
            g.categoria = f.get("categoria") or g.categoria
            g.descripcion = f.get("descripcion", "").strip()
            g.monto = monto
            g.fecha = _parse_fecha(f.get("fecha"))
            g.usuario_id = int(f["usuario_id"]) if f.get("usuario_id") else None
            db.session.commit()
            flash("Gasto actualizado.", "ok")
            return redirect(url_for("gastos"))
        return render_template("editar_gasto.html", g=g,
                               usuarios=User.query.all(),
                               categorias=Gasto.CATEGORIAS)

    @app.route("/gastos/<int:gid>/eliminar", methods=["POST"])
    @login_required
    def eliminar_gasto(gid):
        db.session.delete(Gasto.query.get_or_404(gid))
        db.session.commit()
        return redirect(url_for("gastos"))

    @app.route("/gastos/export.csv")
    @login_required
    def exportar_gastos():
        per = _contexto_periodo()
        filas = _filtrar_mes(Gasto.query, Gasto.fecha, per) \
            .order_by(Gasto.fecha.asc(), Gasto.id.asc()).all()
        rows = [[
            g.fecha, g.categoria, g.descripcion or "",
            g.usuario.nombre if g.usuario else "", f"Bs. {g.monto:,.2f}"
        ] for g in filas]
        return _csv_response(f"gastos_{per['periodo']}.csv",
                             ["Fecha", "Categoría", "Descripción", "Pagó", "Monto (Bs.)"],
                             rows)

    # ---------- Balance / Reparto ----------
    @app.route("/balance")
    @login_required
    def balance():
        per = _contexto_periodo()
        historial = Liquidacion.query.order_by(
            Liquidacion.fecha.desc(), Liquidacion.id.desc()).all()
        return render_template("balance.html",
                               bal=calcular_balance(per["anio"], per["mes"]),
                               per=per, historial=historial, meses=MESES)

    @app.route("/balance/liquidar", methods=["POST"])
    @login_required
    def liquidar_balance():
        """
        Registra una transferencia entre socios (total o PARCIAL). La dirección
        (quién paga a quién) la determina el servidor a partir del ajuste; el
        monto es editable por el usuario para permitir pagos parciales. No toca
        ingresos ni gastos.
        """
        anio, mes = parse_periodo(request.form.get("periodo"))
        bal = calcular_balance(anio, mes)
        sug = bal.get("liquidacion_sugerida")
        if not sug:
            flash("Las cuentas de este mes ya están a mano.", "ok")
            return redirect(url_for("balance", periodo=periodo_str(anio, mes)))

        # Monto editable: por defecto la sugerencia, tope = ajuste pendiente
        try:
            monto = float(request.form.get("monto") or sug["monto"])
        except ValueError:
            monto = sug["monto"]
        if monto <= 0:
            flash("El monto a transferir debe ser mayor a 0.", "error")
            return redirect(url_for("balance", periodo=periodo_str(anio, mes)))
        # No permitir pagar de más y voltear el desbalance
        monto = round(min(monto, sug["monto"]), 2)

        db.session.add(Liquidacion(
            anio=anio, mes=mes, fecha=date.today(), monto=monto,
            pagador_id=sug["pagador"].id, receptor_id=sug["receptor"].id,
        ))
        db.session.commit()

        remanente = round(sug["monto"] - monto, 2)
        if remanente <= 0:
            flash(f"{sug['pagador'].nombre} le pagó Bs. {monto:,.0f} a "
                  f"{sug['receptor'].nombre}. Cuentas saldadas ✔", "ok")
        else:
            flash(f"Pago parcial de Bs. {monto:,.0f} registrado "
                  f"({sug['pagador'].nombre} → {sug['receptor'].nombre}). "
                  f"Saldo remanente del mes: Bs. {remanente:,.0f}.", "ok")
        return redirect(url_for("balance", periodo=periodo_str(anio, mes)))

    @app.route("/balance/liquidar/<int:lid>/eliminar", methods=["POST"])
    @login_required
    def eliminar_liquidacion(lid):
        """Revierte (elimina) una transferencia; el balance se recalcula solo."""
        liq = Liquidacion.query.get_or_404(lid)
        destino = periodo_str(liq.anio, liq.mes)
        db.session.delete(liq)
        db.session.commit()
        flash("Liquidación revertida. El ajuste del mes se recalculó.", "ok")
        return redirect(url_for("balance", periodo=destino))

    # ---------- Deudas e Inversiones de Capital (módulo independiente) ----------
    @app.route("/inversiones")
    @login_required
    def inversiones():
        lista = Inversion.query.order_by(Inversion.fecha.desc(), Inversion.id.desc()).all()
        total_activos = sum(i.monto_total or 0 for i in lista)
        deuda_abierta = sum(i.deuda_pendiente or 0 for i in lista if i.estado == "Pendiente")
        historial_abonos = AbonoInversion.query.order_by(
            AbonoInversion.fecha.desc(), AbonoInversion.id.desc()).all()
        return render_template("inversiones.html", inversiones=lista,
                               total_activos=total_activos, deuda_abierta=deuda_abierta,
                               estados=Inversion.ESTADOS, historial_abonos=historial_abonos)

    @app.route("/inversiones/nueva", methods=["POST"])
    @login_required
    def nueva_inversion():
        f = request.form
        aporte_j = float(f.get("aporte_jorge") or 0)
        aporte_t = float(f.get("aporte_tefi") or 0)
        deuda = Inversion.deuda_inicial(aporte_j, aporte_t)
        inv = Inversion(
            descripcion=f.get("descripcion", "").strip(),
            monto_total=float(f.get("monto_total") or 0),
            aporte_jorge=aporte_j,
            aporte_tefi=aporte_t,
            deuda_pendiente=deuda,
            estado="Saldada" if deuda <= 0 else "Pendiente",
            fecha=_parse_fecha(f.get("fecha")),
        )
        if not inv.descripcion:
            flash("La descripción de la inversión es obligatoria.", "error")
        else:
            db.session.add(inv)
            db.session.commit()
            flash("Inversión registrada.", "ok")
        return redirect(url_for("inversiones"))

    @app.route("/inversiones/<int:iid>/abono", methods=["POST"])
    @login_required
    def abonar_inversion(iid):
        inv = Inversion.query.get_or_404(iid)

        # Control de permisos: solo el socio DEUDOR puede abonar su deuda.
        # El acreedor no debe poder descontar la deuda del otro por error.
        if inv.estado == "Saldada" or not inv.deudor_username:
            flash("Esta inversión no tiene deuda pendiente que abonar.", "error")
            return redirect(url_for("inversiones"))
        if current_user.username != inv.deudor_username:
            flash(f"Solo {inv.deudor} (el socio deudor) puede registrar abonos "
                  f"de «{inv.descripcion}».", "error")
            return redirect(url_for("inversiones"))

        monto = float(request.form.get("monto") or 0)
        if monto <= 0:
            flash("El abono debe ser mayor a 0.", "error")
            return redirect(url_for("inversiones"))
        # No abonar más de lo que se debe
        monto = round(min(monto, inv.deuda_pendiente or 0.0), 2)

        inv.deuda_pendiente = round(max((inv.deuda_pendiente or 0) - monto, 0.0), 2)
        if inv.deuda_pendiente <= 0:
            inv.deuda_pendiente = 0.0
            inv.estado = "Saldada"

        # Trazabilidad: registra el abono con el saldo resultante y nota opcional
        db.session.add(AbonoInversion(
            inversion_id=inv.id, usuario_id=current_user.id, monto=monto,
            saldo_restante=inv.deuda_pendiente,
            nota=(request.form.get("nota") or "").strip() or None,
            fecha=date.today(),
        ))
        db.session.commit()

        if inv.estado == "Saldada":
            flash(f"Abono de Bs. {monto:,.0f} registrado. "
                  f"Deuda de «{inv.descripcion}» saldada por completo ✔", "ok")
        else:
            flash(f"Abono de Bs. {monto:,.0f} registrado. "
                  f"Saldo restante: Bs. {inv.deuda_pendiente:,.0f}.", "ok")
        return redirect(url_for("inversiones"))

    @app.route("/inversiones/<int:iid>/eliminar", methods=["POST"])
    @login_required
    def eliminar_inversion(iid):
        db.session.delete(Inversion.query.get_or_404(iid))
        db.session.commit()
        flash("Inversión eliminada.", "ok")
        return redirect(url_for("inversiones"))

    # Filtro para formatear plata en las plantillas (moneda: Bolivianos)
    @app.template_filter("money")
    def money(v):
        try:
            return "Bs. {:,.0f}".format(float(v or 0))
        except (ValueError, TypeError):
            return "Bs. 0"


app = crear_app()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
